from matplotlib import pyplot as plt
import timeit
import sys
import subprocess

thresholds = [90,50,25,10,5]
fp_tree = []
apriori = []
    
for support_threshold in thresholds:
    fp_tree.append(timeit.timeit('subprocess.run(["fpgrowth/fpgrowth/src/fpgrowth", "{}", "{}", "fp.txt"])'.format("-s" + str(support_threshold), sys.argv[1]) , setup= 'import subprocess' , number=1))
    apriori.append(timeit.timeit('subprocess.run(["./apriori", "{}", "{}", "apriori"])'.format(sys.argv[1], str(support_threshold)) , setup= 'import subprocess' , number=1))
    
    
plt.plot(thresholds, fp_tree, label = 'FP-Tree')
plt.plot(thresholds, apriori, label = 'Apriori')
plt.title('Execution time comparison')
plt.xlabel('Support Threshold')
plt.ylabel('Execution Time (s)')
plt.legend(loc='upper right')
plt.savefig('plot.png')
plt.show()

