#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <algorithm>
#include <utility>
using namespace std;

bool check_equal(const set<int> &itemset1, const set<int> &itemset2){
	if(itemset1.size() == itemset2.size()){
		auto itr1 = itemset1.begin();
		auto itr2 = itemset2.begin();
		while(itr1 != itemset1.end()){
			if(*itr1 != *itr2){
				return false;
			}
			itr1++;
			itr2++;
		}
		return true;
	}
	
	else{
		return false;
	}
}

bool present(const vector<pair<set<int>,int>> &cs, const pair<set<int>,int> &cand){
	for(int i=0; i<cs.size();i++){
		if(check_equal(cs[i].first, cand.first)){
			return true;
		}
	}
	return false;
}

bool subset_check(set<int> itemset, const vector<pair<set<int>,int>> &F, int remove){
	itemset.erase(remove);
	for(int i = 0; i < F.size(); i++){
		if(check_equal(F[i].first, itemset)){
			return true;
		}
	}
	return false;
}

void candidate_generation(const vector<pair<set<int>,int>> &F, vector<pair<set<int>,int>> &C){
	for(int i = 0; i < F.size(); i++){
		for(int j = i+1; j < F.size(); j++){
			set<int> temp1, temp2;
			temp1 = F[i].first;
			temp2 = F[j].first;
			int k;
			pair<set<int>,int> t;
			t.second = 0;
			auto itr1 = temp1.begin();
			auto itr2 = temp2.begin();
			for(k = 0 ;  k < temp1.size()-1 ; k++){	

				if(*itr1 == *itr2){
					t.first.insert(*itr2);
					itr1++;
					itr2++;
				}
				else{
					break;
				}
			}

			if(k == temp1.size()-1){
				if(*itr1< *itr2){
					t.first.insert(*itr1);
					t.first.insert(*itr2);
				}
			}
			else{
				break;
			}

			bool check;
			for(auto i=t.first.begin(); i!=t.first.end();i++){
				check = subset_check(t.first, F, *i);
				if(check == false){
					break;
				}
			}

			if(check == true){
				if(!(present(C, t))){
					C.push_back(t);
				}
				
			}
	
		}
	}

}

int main(int argc, char *argv[]){
	string transaction;
	int item;
	int transaction_count = 0;
	vector<vector<pair<set<int>,int>>> frequent_sets;
	map<int, int> cand1;

	ifstream inFile;
	inFile.open(argv[1]);

	while(getline(inFile, transaction)){
		transaction_count++;
		stringstream items(transaction);
		while(items >> item){
			if(cand1.find(item) == cand1.end()){
				cand1[item] = 1;
			}
			else{
				cand1[item]++;
			}

		}

	}

	double support_threshold = (stod(argv[2])*transaction_count)/100;

	vector<pair<set<int>,int>> freq;
	for(auto it=cand1.begin(); it!=cand1.end(); it++){

		if(it->second >= support_threshold){
			pair<set<int>,int> temp;
			temp.first.insert(it->first);
			temp.second = it->second;
			freq.push_back(temp);
		} 
		
	}

	frequent_sets.push_back(freq);

	while(true){
		freq.clear();
		candidate_generation(frequent_sets.back(), freq);
		
		inFile.clear();
		inFile.seekg(0, inFile.beg);
		while(getline(inFile, transaction)){
			stringstream items(transaction);
			set<int> temp;
			while(items >> item){	
				temp.insert(item);
			}
			for(int i=0; i<freq.size();i++){
				if(includes(temp.begin(), temp.end(), freq[i].first.begin(), freq[i].first.end())){
					if(freq[i].second == 0){
						freq[i].second = 1;
					}
					else{
						freq[i].second += 1;
					}
				}
			}
		}

		auto itr = freq.begin();
		while(itr != freq.end()){
			if((*itr).second < support_threshold){
				itr = freq.erase(itr);
			}
			else{
				itr++;
			}
		}

		if(freq.empty()){
			break;
		}
		else{
			frequent_sets.push_back(freq);
		}
	}

	ofstream outFile;
	string outfilename = argv[3];
	outFile.open(outfilename + ".txt");
	for(const auto &fs : frequent_sets){
		for(const auto &cs : fs){
			for(const auto &i : cs.first){
				outFile << i << " ";
			}
			outFile << "\n";	
		}
	}

	outFile.close();
	inFile.close();

	return 0;
}